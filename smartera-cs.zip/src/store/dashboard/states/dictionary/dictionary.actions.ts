import { DictionaryStateModel } from './dictionary.state';

export class SetDictionaryData {
  static readonly type = '[Dictionary] Set dictionary data action';
  constructor(readonly payload: DictionaryStateModel) {}
}

export class DictionaryReset {
  static readonly type = '[Dictionary] Reset dictionary action';
}
