import { AuthenticationStateModel } from './auth.state';

export class SetAuthData {
  static readonly type = '[Auth] Auth data';
  constructor(readonly payload: AuthenticationStateModel) {}
}
